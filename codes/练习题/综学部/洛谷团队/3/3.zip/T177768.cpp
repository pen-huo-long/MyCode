//https://www.luogu.com.cn/problem/T177768

#include<bits/stdc++.h>
using namespace std;

int x;
//递归
int solve(int m, int n) {
    if (n == 1 || m == 1)
        return 1;
    return solve(m - 1, n) + solve(m, n - 1);
}

void solve2() {
    int a[100][100];
    a[1][1] = 1;
    a[1][2] = 1;
    a[2][1] = 1;
    a[2][2] = 2;
    for (int i = 3; i <= x; ++i) {
        for (int j = 3; j <= x; ++j) {
            a[i][j] = a[i][j - 1] + a[i - 1][j];
        }
    }
    cout << a[x][x];
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    cin >> x;
    //cout << solve(x, x);
    solve2();
    return 0;
}